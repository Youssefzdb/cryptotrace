import Layout from "@/components/Layout";
import ContractCard from "@/components/ContractCard";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Contract } from "@shared/schema";
import { useState } from "react";
import { Coins, Filter } from "lucide-react";

export default function Contracts() {
  const [selectedFilter, setSelectedFilter] = useState<string>("all");

  const { data: contracts, isLoading } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
  });

  const filteredContracts = contracts?.filter(contract => {
    if (selectedFilter === "all") return true;
    return contract.cryptocurrency.toLowerCase() === selectedFilter.toLowerCase();
  }) || [];

  const filters = [
    { id: "all", label: "جميع العقود", count: contracts?.length || 0 },
    { id: "btc", label: "البيتكوين", count: contracts?.filter(c => c.cryptocurrency.toLowerCase() === "btc").length || 0 },
    { id: "eth", label: "الإيثريوم", count: contracts?.filter(c => c.cryptocurrency.toLowerCase() === "eth").length || 0 },
    { id: "ltc", label: "لايتكوين", count: contracts?.filter(c => c.cryptocurrency.toLowerCase() === "ltc").length || 0 },
  ];

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">عقود التعدين المتاحة</h1>
          <p className="text-xl text-muted-foreground">اختر العقد المناسب لك وابدأ في تحقيق الأرباح اليومية</p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          {filters.map((filter) => (
            <Button
              key={filter.id}
              variant={selectedFilter === filter.id ? "default" : "outline"}
              className={selectedFilter === filter.id ? "bg-primary text-primary-foreground" : ""}
              onClick={() => setSelectedFilter(filter.id)}
            >
              {filter.label}
              <Badge variant="secondary" className="mr-2">
                {filter.count}
              </Badge>
            </Button>
          ))}
        </div>

        {/* Contracts Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="mining-card rounded-2xl p-6 animate-pulse">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <div className="w-10 h-10 bg-muted rounded-full"></div>
                    <div>
                      <div className="h-4 bg-muted rounded w-20 mb-2"></div>
                      <div className="h-3 bg-muted rounded w-16"></div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {[...Array(3)].map((_, j) => (
                    <div key={j} className="flex justify-between">
                      <div className="h-3 bg-muted rounded w-16"></div>
                      <div className="h-3 bg-muted rounded w-12"></div>
                    </div>
                  ))}
                  
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <div className="h-3 bg-muted rounded w-12"></div>
                      <div className="h-3 bg-muted rounded w-16"></div>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2"></div>
                  </div>

                  <div className="w-full bg-muted rounded-lg h-10"></div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredContracts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredContracts.map((contract) => (
              <ContractCard key={contract.id} contract={contract} />
            ))}
          </div>
        ) : (
          <Card className="text-center py-12">
            <CardContent>
              <Coins className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">لا توجد عقود متاحة</h3>
              <p className="text-muted-foreground mb-4">
                {selectedFilter === "all" 
                  ? "لا توجد عقود تعدين متاحة حالياً"
                  : `لا توجد عقود ${filters.find(f => f.id === selectedFilter)?.label} متاحة حالياً`
                }
              </p>
              <Button
                variant="outline"
                onClick={() => setSelectedFilter("all")}
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
              >
                عرض جميع العقود
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Info Section */}
        <div className="mt-16 text-center">
          <Card className="mining-card max-w-4xl mx-auto">
            <CardContent className="pt-6">
              <h3 className="text-2xl font-bold mb-4">كيف تعمل عقود التعدين؟</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-right">
                <div>
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-primary-foreground font-bold">1</span>
                  </div>
                  <h4 className="font-semibold mb-2">اختر العقد</h4>
                  <p className="text-sm text-muted-foreground">اختر العقد المناسب لميزانيتك وأهدافك الاستثمارية</p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-primary-foreground font-bold">2</span>
                  </div>
                  <h4 className="font-semibold mb-2">ادفع واشتري</h4>
                  <p className="text-sm text-muted-foreground">ادفع قيمة العقد وسيبدأ التعدين تلقائياً</p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-primary-foreground font-bold">3</span>
                  </div>
                  <h4 className="font-semibold mb-2">احصل على الأرباح</h4>
                  <p className="text-sm text-muted-foreground">تستلم الأرباح يومياً في حسابك</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
