import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { DollarSign, TrendingUp, FileText, Users } from "lucide-react";

type DashboardStatsData = {
  totalBalance: string;
  dailyProfit: string;
  activeContracts: number;
  totalReferrals: number;
};

export default function DashboardStats() {
  const { data: stats, isLoading } = useQuery<DashboardStatsData>({
    queryKey: ["/api/dashboard/stats"],
  });

  const statsItems = [
    {
      title: "الرصيد الكلي",
      value: stats ? `$${stats.totalBalance}` : "$0.00",
      icon: DollarSign,
      color: "text-green-500",
      bgColor: "bg-green-500/20",
    },
    {
      title: "الأرباح اليومية",
      value: stats ? `$${stats.dailyProfit}` : "$0.00",
      icon: TrendingUp,
      color: "text-yellow-500",
      bgColor: "bg-yellow-500/20",
    },
    {
      title: "العقود النشطة",
      value: stats ? stats.activeContracts.toString() : "0",
      icon: FileText,
      color: "text-blue-500",
      bgColor: "bg-blue-500/20",
    },
    {
      title: "الإحالات",
      value: stats ? stats.totalReferrals.toString() : "0",
      icon: Users,
      color: "text-purple-500",
      bgColor: "bg-purple-500/20",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="mining-card animate-pulse">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <div className="h-4 bg-muted rounded w-20"></div>
                  <div className="h-6 bg-muted rounded w-16"></div>
                </div>
                <div className="w-12 h-12 bg-muted rounded-lg"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statsItems.map((item, index) => {
        const Icon = item.icon;
        return (
          <Card key={index} className="mining-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">{item.title}</p>
                  <p className={`text-2xl font-bold ${item.color}`}>
                    {item.value}
                  </p>
                </div>
                <div className={`w-12 h-12 ${item.bgColor} rounded-lg flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 ${item.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
