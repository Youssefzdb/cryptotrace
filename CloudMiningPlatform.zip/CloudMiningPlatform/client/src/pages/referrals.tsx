import Layout from "@/components/Layout";
import ReferralSection from "@/components/ReferralSection";

export default function Referrals() {
  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">برنامج الإحالات</h1>
          <p className="text-xl text-muted-foreground">احصل على 10% من أرباح كل شخص تدعوه للمنصة</p>
        </div>

        <ReferralSection />
      </div>
    </Layout>
  );
}
