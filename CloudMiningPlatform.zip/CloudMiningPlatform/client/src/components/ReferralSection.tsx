import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Referral, User } from "@shared/schema";
import { Copy, Users, DollarSign, TrendingUp, Calendar, ExternalLink } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

type ReferralStats = {
  totalReferrals: number;
  totalCommission: string;
  activeReferrals: number;
  monthlyCommission: string;
};

export default function ReferralSection() {
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: referralStats } = useQuery<ReferralStats>({
    queryKey: ["/api/referrals/stats"],
  });

  const { data: referrals } = useQuery<(Referral & { referred: User })[]>({
    queryKey: ["/api/referrals"],
  });

  const referralLink = user?.referralCode 
    ? `${window.location.origin}?ref=${user.referralCode}`
    : `${window.location.origin}?ref=USER123`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      toast({
        title: "تم نسخ الرابط",
        description: "تم نسخ رابط الإحالة إلى الحافظة",
      });
    } catch (error) {
      // Fallback for older browsers
      const textArea = document.createElement("textarea");
      textArea.value = referralLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      
      toast({
        title: "تم نسخ الرابط",
        description: "تم نسخ رابط الإحالة إلى الحافظة",
      });
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="space-y-8">
      {/* Referral Link and Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Referral Link */}
        <Card className="mining-card">
          <CardHeader>
            <CardTitle className="text-xl">رابط الإحالة الخاص بك</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-2 space-x-reverse bg-secondary rounded-lg p-3">
                <Input 
                  value={referralLink}
                  readOnly
                  className="bg-transparent border-0 text-muted-foreground outline-none focus:ring-0 focus:border-0"
                />
                <Button 
                  onClick={handleCopyLink}
                  className="bg-primary hover:bg-primary/90 shrink-0"
                >
                  <Copy className="w-4 h-4 ml-2" />
                  نسخ
                </Button>
              </div>
              <p className="text-sm text-muted-foreground text-right">
                شارك هذا الرابط مع أصدقائك واحصل على 10% عمولة من جميع استثماراتهم
              </p>
              
              {/* Social Share Buttons */}
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    const text = `انضم إلى منصة CloudMine للتعدين السحابي واحصل على أرباح يومية مضمونة! ${referralLink}`;
                    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                  }}
                  className="flex-1"
                >
                  WhatsApp
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    const text = `انضم إلى منصة CloudMine للتعدين السحابي ${referralLink}`;
                    window.open(`https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(text)}`, '_blank');
                  }}
                  className="flex-1"
                >
                  Telegram
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Referral Stats */}
        <Card className="mining-card">
          <CardHeader>
            <CardTitle className="text-xl">إحصائيات الإحالات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-400">
                  {referralStats?.totalReferrals || 0}
                </div>
                <div className="text-sm text-muted-foreground">إجمالي الإحالات</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-500">
                  ${referralStats?.totalCommission || "0.00"}
                </div>
                <div className="text-sm text-muted-foreground">إجمالي الأرباح</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-500">
                  {referralStats?.activeReferrals || 0}
                </div>
                <div className="text-sm text-muted-foreground">الإحالات النشطة</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">
                  ${referralStats?.monthlyCommission || "0.00"}
                </div>
                <div className="text-sm text-muted-foreground">أرباح هذا الشهر</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* How it Works */}
      <Card className="mining-card">
        <CardHeader>
          <CardTitle className="text-xl text-center">كيف يعمل برنامج الإحالات؟</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-primary-foreground font-bold">1</span>
              </div>
              <h4 className="font-semibold mb-2">شارك الرابط</h4>
              <p className="text-sm text-muted-foreground">
                انسخ رابط الإحالة الخاص بك وشاركه مع أصدقائك
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-primary-foreground font-bold">2</span>
              </div>
              <h4 className="font-semibold mb-2">الأصدقاء ينضمون</h4>
              <p className="text-sm text-muted-foreground">
                عندما ينقر أصدقاؤك على رابطك ويسجلون في المنصة
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-primary-foreground font-bold">3</span>
              </div>
              <h4 className="font-semibold mb-2">تحصل على العمولة</h4>
              <p className="text-sm text-muted-foreground">
                احصل على 10% من جميع استثماراتهم كعمولة
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Referrals */}
      <Card className="mining-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl">الإحالات الأخيرة</CardTitle>
            {referrals && referrals.length > 5 && (
              <Button variant="outline" size="sm">
                <ExternalLink className="w-4 h-4 ml-2" />
                عرض الكل
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {referrals && referrals.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">المستخدم</TableHead>
                    <TableHead className="text-right">تاريخ التسجيل</TableHead>
                    <TableHead className="text-right">العمولة الإجمالية</TableHead>
                    <TableHead className="text-right">الحالة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {referrals.slice(0, 10).map((referral) => (
                    <TableRow key={referral.id}>
                      <TableCell className="font-medium">
                        {referral.referred.firstName 
                          ? `${referral.referred.firstName} ${referral.referred.lastName || ''}`
                          : referral.referred.email?.split('@')[0] || `User${referral.referred.id.slice(-4)}`
                        }
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDate(referral.createdAt)}
                      </TableCell>
                      <TableCell className="text-green-500 font-medium">
                        ${referral.totalCommission}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={referral.isActive ? "default" : "secondary"}
                          className={referral.isActive ? "bg-green-500 text-white" : ""}
                        >
                          {referral.isActive ? "نشط" : "غير نشط"}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">لا توجد إحالات بعد</h3>
              <p className="text-muted-foreground mb-4">
                ابدأ بدعوة أصدقائك للانضمام إلى المنصة واحصل على عمولة من استثماراتهم
              </p>
              <Button onClick={handleCopyLink} className="bg-primary hover:bg-primary/90">
                <Copy className="w-4 h-4 ml-2" />
                نسخ رابط الإحالة
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
