import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Transaction } from "@shared/schema";
import { 
  DollarSign, 
  TrendingUp, 
  ShoppingCart, 
  Users, 
  ArrowUpDown,
  Clock,
  ExternalLink
} from "lucide-react";

export default function TransactionHistory() {
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'mining_profit':
        return TrendingUp;
      case 'contract_purchase':
        return ShoppingCart;
      case 'referral_commission':
        return Users;
      case 'deposit':
        return ArrowUpDown;
      case 'withdrawal':
        return ArrowUpDown;
      default:
        return DollarSign;
    }
  };

  const getTransactionColor = (type: string, amount: string) => {
    const numAmount = parseFloat(amount);
    if (numAmount > 0) {
      return "text-green-500";
    } else {
      return "text-red-500";
    }
  };

  const getTransactionBgColor = (type: string) => {
    switch (type) {
      case 'mining_profit':
        return "bg-green-500/20";
      case 'contract_purchase':
        return "bg-red-500/20";
      case 'referral_commission':
        return "bg-purple-500/20";
      case 'deposit':
        return "bg-blue-500/20";
      case 'withdrawal':
        return "bg-orange-500/20";
      default:
        return "bg-gray-500/20";
    }
  };

  const getTransactionLabel = (type: string) => {
    switch (type) {
      case 'mining_profit':
        return 'ربح من التعدين';
      case 'contract_purchase':
        return 'شراء عقد';
      case 'referral_commission':
        return 'مكافأة الإحالة';
      case 'deposit':
        return 'إيداع';
      case 'withdrawal':
        return 'سحب';
      default:
        return 'معاملة';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <Card className="mining-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl">تاريخ المعاملات</CardTitle>
          <Button variant="outline" size="sm">
            <ExternalLink className="w-4 h-4 ml-2" />
            عرض الكل
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center justify-between py-3 border-b border-border animate-pulse">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="w-10 h-10 bg-muted rounded-lg"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-muted rounded w-24"></div>
                    <div className="h-3 bg-muted rounded w-32"></div>
                  </div>
                </div>
                <div className="h-4 bg-muted rounded w-16"></div>
              </div>
            ))}
          </div>
        ) : transactions && transactions.length > 0 ? (
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {transactions.slice(0, 10).map((transaction) => {
              const Icon = getTransactionIcon(transaction.type);
              const amount = parseFloat(transaction.amount);
              const isPositive = amount > 0;
              
              return (
                <div key={transaction.id} className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <div className={`w-10 h-10 ${getTransactionBgColor(transaction.type)} rounded-lg flex items-center justify-center`}>
                      <Icon className={`w-5 h-5 ${getTransactionColor(transaction.type, transaction.amount)}`} />
                    </div>
                    <div>
                      <p className="font-medium">
                        {transaction.description || getTransactionLabel(transaction.type)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {formatDate(transaction.createdAt)}
                      </p>
                      {transaction.status && transaction.status !== 'completed' && (
                        <Badge variant="outline" className="text-xs mt-1">
                          {transaction.status === 'pending' ? 'قيد المعالجة' : 'فشل'}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="text-left">
                    <span className={`font-medium ${getTransactionColor(transaction.type, transaction.amount)}`}>
                      {isPositive ? '+' : ''}${Math.abs(amount).toFixed(2)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8">
            <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">لا توجد معاملات بعد</p>
            <p className="text-sm text-muted-foreground">
              ستظهر هنا جميع معاملاتك من شراء العقود والأرباح والإحالات
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
