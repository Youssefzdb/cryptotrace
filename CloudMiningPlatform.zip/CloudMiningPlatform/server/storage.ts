import {
  users,
  contracts,
  userContracts,
  transactions,
  referrals,
  type User,
  type UpsertUser,
  type Contract,
  type InsertContract,
  type UserContract,
  type InsertUserContract,
  type Transaction,
  type InsertTransaction,
  type Referral,
  type InsertReferral,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sum, count } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserBalance(userId: string, amount: string): Promise<void>;
  generateReferralCode(userId: string): Promise<string>;

  // Contract operations
  getContracts(): Promise<Contract[]>;
  getContract(id: number): Promise<Contract | undefined>;
  createContract(contract: InsertContract): Promise<Contract>;
  updateContract(id: number, contract: Partial<InsertContract>): Promise<Contract>;
  deleteContract(id: number): Promise<void>;

  // User contract operations
  getUserContracts(userId: string): Promise<(UserContract & { contract: Contract })[]>;
  purchaseContract(userContract: InsertUserContract): Promise<UserContract>;
  getActiveUserContracts(userId: string): Promise<(UserContract & { contract: Contract })[]>;

  // Transaction operations
  getTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getUserStats(userId: string): Promise<{
    totalBalance: string;
    dailyProfit: string;
    activeContracts: number;
    totalReferrals: number;
  }>;

  // Referral operations
  getReferrals(userId: string): Promise<(Referral & { referred: User })[]>;
  createReferral(referral: InsertReferral): Promise<Referral>;
  getReferralStats(userId: string): Promise<{
    totalReferrals: number;
    totalCommission: string;
    activeReferrals: number;
    monthlyCommission: string;
  }>;
  getUserByReferralCode(code: string): Promise<User | undefined>;

  // Admin operations
  getAdminStats(): Promise<{
    totalUsers: number;
    totalContracts: number;
    totalRevenue: string;
    activeUsers: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, amount: string): Promise<void> {
    await db
      .update(users)
      .set({ 
        balance: amount,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  async generateReferralCode(userId: string): Promise<string> {
    const code = `REF${userId.slice(-6).toUpperCase()}`;
    await db
      .update(users)
      .set({ 
        referralCode: code,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
    return code;
  }

  // Contract operations
  async getContracts(): Promise<Contract[]> {
    return await db.select().from(contracts).where(eq(contracts.isActive, true)).orderBy(contracts.id);
  }

  async getContract(id: number): Promise<Contract | undefined> {
    const [contract] = await db.select().from(contracts).where(eq(contracts.id, id));
    return contract;
  }

  async createContract(contract: InsertContract): Promise<Contract> {
    const [newContract] = await db
      .insert(contracts)
      .values(contract)
      .returning();
    return newContract;
  }

  async updateContract(id: number, contract: Partial<InsertContract>): Promise<Contract> {
    const [updatedContract] = await db
      .update(contracts)
      .set({ ...contract, updatedAt: new Date() })
      .where(eq(contracts.id, id))
      .returning();
    return updatedContract;
  }

  async deleteContract(id: number): Promise<void> {
    await db
      .update(contracts)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(contracts.id, id));
  }

  // User contract operations
  async getUserContracts(userId: string): Promise<(UserContract & { contract: Contract })[]> {
    return await db
      .select({
        id: userContracts.id,
        userId: userContracts.userId,
        contractId: userContracts.contractId,
        amount: userContracts.amount,
        dailyProfit: userContracts.dailyProfit,
        totalProfit: userContracts.totalProfit,
        startDate: userContracts.startDate,
        endDate: userContracts.endDate,
        isActive: userContracts.isActive,
        createdAt: userContracts.createdAt,
        contract: contracts,
      })
      .from(userContracts)
      .innerJoin(contracts, eq(userContracts.contractId, contracts.id))
      .where(eq(userContracts.userId, userId))
      .orderBy(desc(userContracts.createdAt));
  }

  async purchaseContract(userContract: InsertUserContract): Promise<UserContract> {
    const [newUserContract] = await db
      .insert(userContracts)
      .values(userContract)
      .returning();
    
    // Update contract sold slots
    const currentContract = await this.getContract(userContract.contractId);
    if (currentContract) {
      await db
        .update(contracts)
        .set({ 
          soldSlots: (currentContract.soldSlots || 0) + 1,
          updatedAt: new Date(),
        })
        .where(eq(contracts.id, userContract.contractId));
    }

    return newUserContract;
  }

  async getActiveUserContracts(userId: string): Promise<(UserContract & { contract: Contract })[]> {
    return await db
      .select({
        id: userContracts.id,
        userId: userContracts.userId,
        contractId: userContracts.contractId,
        amount: userContracts.amount,
        dailyProfit: userContracts.dailyProfit,
        totalProfit: userContracts.totalProfit,
        startDate: userContracts.startDate,
        endDate: userContracts.endDate,
        isActive: userContracts.isActive,
        createdAt: userContracts.createdAt,
        contract: contracts,
      })
      .from(userContracts)
      .innerJoin(contracts, eq(userContracts.contractId, contracts.id))
      .where(and(
        eq(userContracts.userId, userId),
        eq(userContracts.isActive, true)
      ))
      .orderBy(desc(userContracts.createdAt));
  }

  // Transaction operations
  async getTransactions(userId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt))
      .limit(50);
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db
      .insert(transactions)
      .values(transaction)
      .returning();
    return newTransaction;
  }

  async getUserStats(userId: string): Promise<{
    totalBalance: string;
    dailyProfit: string;
    activeContracts: number;
    totalReferrals: number;
  }> {
    const user = await this.getUser(userId);
    const activeContracts = await db
      .select({ count: count() })
      .from(userContracts)
      .where(and(
        eq(userContracts.userId, userId),
        eq(userContracts.isActive, true)
      ));

    const dailyProfitResult = await db
      .select({ total: sum(userContracts.dailyProfit) })
      .from(userContracts)
      .where(and(
        eq(userContracts.userId, userId),
        eq(userContracts.isActive, true)
      ));

    const referralCount = await db
      .select({ count: count() })
      .from(referrals)
      .where(eq(referrals.referrerId, userId));

    return {
      totalBalance: user?.balance || "0.00",
      dailyProfit: dailyProfitResult[0]?.total || "0.00",
      activeContracts: activeContracts[0]?.count || 0,
      totalReferrals: referralCount[0]?.count || 0,
    };
  }

  // Referral operations
  async getReferrals(userId: string): Promise<(Referral & { referred: User })[]> {
    return await db
      .select({
        id: referrals.id,
        referrerId: referrals.referrerId,
        referredId: referrals.referredId,
        commissionRate: referrals.commissionRate,
        totalCommission: referrals.totalCommission,
        isActive: referrals.isActive,
        createdAt: referrals.createdAt,
        referred: users,
      })
      .from(referrals)
      .innerJoin(users, eq(referrals.referredId, users.id))
      .where(eq(referrals.referrerId, userId))
      .orderBy(desc(referrals.createdAt));
  }

  async createReferral(referral: InsertReferral): Promise<Referral> {
    const [newReferral] = await db
      .insert(referrals)
      .values(referral)
      .returning();
    return newReferral;
  }

  async getReferralStats(userId: string): Promise<{
    totalReferrals: number;
    totalCommission: string;
    activeReferrals: number;
    monthlyCommission: string;
  }> {
    const totalReferralsResult = await db
      .select({ count: count() })
      .from(referrals)
      .where(eq(referrals.referrerId, userId));

    const activeReferralsResult = await db
      .select({ count: count() })
      .from(referrals)
      .where(and(
        eq(referrals.referrerId, userId),
        eq(referrals.isActive, true)
      ));

    const totalCommissionResult = await db
      .select({ total: sum(referrals.totalCommission) })
      .from(referrals)
      .where(eq(referrals.referrerId, userId));

    // For monthly commission, we'll use the same total for now
    // In a real app, you'd filter by date
    const monthlyCommissionResult = totalCommissionResult;

    return {
      totalReferrals: totalReferralsResult[0]?.count || 0,
      totalCommission: totalCommissionResult[0]?.total || "0.00",
      activeReferrals: activeReferralsResult[0]?.count || 0,
      monthlyCommission: monthlyCommissionResult[0]?.total || "0.00",
    };
  }

  async getUserByReferralCode(code: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.referralCode, code));
    return user;
  }

  // Admin operations
  async getAdminStats(): Promise<{
    totalUsers: number;
    totalContracts: number;
    totalRevenue: string;
    activeUsers: number;
  }> {
    const totalUsersResult = await db.select({ count: count() }).from(users);
    const totalContractsResult = await db.select({ count: count() }).from(contracts);
    const totalRevenueResult = await db
      .select({ total: sum(transactions.amount) })
      .from(transactions)
      .where(eq(transactions.type, "contract_purchase"));

    // For active users, count users with active contracts
    const activeUsersResult = await db
      .selectDistinct({ userId: userContracts.userId })
      .from(userContracts)
      .where(eq(userContracts.isActive, true));

    return {
      totalUsers: totalUsersResult[0]?.count || 0,
      totalContracts: totalContractsResult[0]?.count || 0,
      totalRevenue: totalRevenueResult[0]?.total || "0.00",
      activeUsers: activeUsersResult.length,
    };
  }
}

export const storage = new DatabaseStorage();
