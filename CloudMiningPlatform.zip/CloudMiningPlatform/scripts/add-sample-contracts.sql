-- إضافة عقود التعدين النموذجية لمنصة CloudMine
-- Sample mining contracts for CloudMine platform

INSERT INTO contracts (name, description, cryptocurrency, min_amount, max_amount, daily_return, total_return, duration, total_slots, sold_slots, is_active) VALUES

-- عقود البيتكوين
('Bitcoin Starter', 'عقد تعدين البيتكوين للمبتدئين - مناسب للاستثمارات الصغيرة', 'BTC', '100.00', '5000.00', '2.50', '130.00', 365, 1000, 247, true),

('Bitcoin Professional', 'عقد تعدين البيتكوين المتقدم - للمستثمرين المحترفين', 'BTC', '5000.00', '50000.00', '3.20', '180.00', 540, 500, 89, true),

-- عقود الإيثريوم  
('Ethereum Growth', 'عقد تعدين الإيثريوم مع عوائد نمو ممتازة', 'ETH', '200.00', '10000.00', '2.80', '150.00', 450, 750, 156, true),

('Ethereum Enterprise', 'عقد تعدين الإيثريوم للشركات والاستثمارات الكبيرة', 'ETH', '10000.00', '100000.00', '3.50', '200.00', 720, 200, 34, true),

-- عقود لايتكوين
('Litecoin Express', 'عقد تعدين لايتكوين سريع الأرباح - مدة قصيرة', 'LTC', '50.00', '2000.00', '2.20', '110.00', 180, 1500, 678, true),

('Litecoin Premium', 'عقد تعدين لايتكوين متميز مع عوائد مرتفعة', 'LTC', '1000.00', '15000.00', '2.90', '160.00', 480, 400, 123, true);

-- تحديث timestamps
UPDATE contracts SET created_at = NOW(), updated_at = NOW() WHERE created_at IS NULL;