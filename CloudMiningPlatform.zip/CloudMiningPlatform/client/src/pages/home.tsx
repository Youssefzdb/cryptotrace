import { useAuth } from "@/hooks/useAuth";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import ContractCard from "@/components/ContractCard";
import DashboardStats from "@/components/DashboardStats";
import { useQuery } from "@tanstack/react-query";
import { Contract } from "@shared/schema";
import { TrendingUp, Users, Shield, Zap } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { user } = useAuth();

  const { data: contracts, isLoading } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
  });

  const featuredContracts = contracts?.slice(0, 3) || [];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="gradient-bg py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight text-right">
                مرحباً بك، {user?.firstName || "المستثمر"}
                <span className="text-primary block">في CloudMine</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed text-right">
                تابع استثماراتك وأرباحك من التعدين السحابي في مكان واحد
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/dashboard">
                  <Button className="bg-primary hover:bg-primary/90 px-8 py-4 text-lg h-auto">
                    لوحة التحكم
                  </Button>
                </Link>
                <Link href="/contracts">
                  <Button 
                    variant="outline" 
                    className="border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-4 text-lg h-auto"
                  >
                    تصفح العقود
                  </Button>
                </Link>
              </div>
            </div>
            
            {/* Dashboard Stats */}
            <DashboardStats />
          </div>
        </div>
      </section>

      {/* Featured Contracts */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">العقود المميزة</h2>
            <Link href="/contracts">
              <Button variant="outline">عرض جميع العقود</Button>
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="mining-card rounded-2xl p-6 animate-pulse">
                  <div className="h-4 bg-muted rounded w-3/4 mb-4"></div>
                  <div className="space-y-3">
                    <div className="h-3 bg-muted rounded"></div>
                    <div className="h-3 bg-muted rounded w-5/6"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : featuredContracts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredContracts.map((contract) => (
                <ContractCard key={contract.id} contract={contract} />
              ))}
            </div>
          ) : (
            <Card className="text-center py-12">
              <CardContent>
                <p className="text-muted-foreground">لا توجد عقود متاحة حالياً</p>
              </CardContent>
            </Card>
          )}
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-muted/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">مميزات المنصة</h2>
            <p className="text-xl text-muted-foreground">استمتع بأفضل تجربة تعدين سحابي</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="mining-card text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">أمان عالي</h3>
                <p className="text-sm text-muted-foreground">حماية متقدمة لاستثماراتك</p>
              </CardContent>
            </Card>

            <Card className="mining-card text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-6 h-6 text-green-500" />
                </div>
                <h3 className="font-semibold mb-2">عوائد يومية</h3>
                <p className="text-sm text-muted-foreground">أرباح يومية مضمونة</p>
              </CardContent>
            </Card>

            <Card className="mining-card text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="font-semibold mb-2">تقنية متقدمة</h3>
                <p className="text-sm text-muted-foreground">أحدث تقنيات التعدين</p>
              </CardContent>
            </Card>

            <Card className="mining-card text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-purple-500" />
                </div>
                <h3 className="font-semibold mb-2">دعم 24/7</h3>
                <p className="text-sm text-muted-foreground">فريق دعم متخصص</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </Layout>
  );
}
