import Layout from "@/components/Layout";
import DashboardStats from "@/components/DashboardStats";
import TransactionHistory from "@/components/TransactionHistory";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { UserContract, Contract } from "@shared/schema";
import { RefreshCw, Clock, DollarSign } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: userContracts, isLoading: contractsLoading, refetch: refetchContracts } = useQuery<(UserContract & { contract: Contract })[]>({
    queryKey: ["/api/dashboard/contracts"],
  });

  const getCryptocurrencyIcon = (crypto: string) => {
    switch (crypto.toLowerCase()) {
      case 'btc':
      case 'bitcoin':
        return '₿';
      case 'eth':
      case 'ethereum':
        return 'Ξ';
      case 'ltc':
      case 'litecoin':
        return 'Ł';
      default:
        return '₿';
    }
  };

  const getCryptocurrencyColor = (crypto: string) => {
    switch (crypto.toLowerCase()) {
      case 'btc':
      case 'bitcoin':
        return 'bg-yellow-500';
      case 'eth':
      case 'ethereum':
        return 'bg-blue-500';
      case 'ltc':
      case 'litecoin':
        return 'bg-gray-400';
      default:
        return 'bg-yellow-500';
    }
  };

  const calculateProgress = (startDate: string | Date, endDate: string | Date) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const now = new Date();
    
    const totalDuration = end.getTime() - start.getTime();
    const elapsed = now.getTime() - start.getTime();
    
    return Math.min(Math.max((elapsed / totalDuration) * 100, 0), 100);
  };

  const getDaysRemaining = (endDate: string | Date) => {
    const end = new Date(endDate);
    const now = new Date();
    const diffTime = end.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(diffDays, 0);
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">لوحة التحكم</h1>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              refetchContracts();
            }}
          >
            <RefreshCw className="w-4 h-4 ml-2" />
            تحديث البيانات
          </Button>
        </div>

        {/* Dashboard Stats */}
        <div className="mb-8">
          <DashboardStats />
        </div>

        {/* Active Contracts and Transaction History */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Active Contracts */}
          <Card className="mining-card">
            <CardHeader>
              <CardTitle className="text-xl">العقود النشطة</CardTitle>
            </CardHeader>
            <CardContent>
              {contractsLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="border border-border rounded-lg p-4 animate-pulse">
                      <div className="h-4 bg-muted rounded w-3/4 mb-3"></div>
                      <div className="space-y-2">
                        <div className="h-3 bg-muted rounded"></div>
                        <div className="h-3 bg-muted rounded w-5/6"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : userContracts && userContracts.length > 0 ? (
                <div className="space-y-4">
                  {userContracts.map((userContract) => (
                    <div key={userContract.id} className="border border-border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3 space-x-reverse">
                          <div className={`w-8 h-8 ${getCryptocurrencyColor(userContract.contract.cryptocurrency)} rounded-full flex items-center justify-center`}>
                            <span className="text-white font-bold text-xs">
                              {getCryptocurrencyIcon(userContract.contract.cryptocurrency)}
                            </span>
                          </div>
                          <div>
                            <h4 className="font-medium">{userContract.contract.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              تم الشراء: {new Date(userContract.startDate).toLocaleDateString('ar-SA')}
                            </p>
                          </div>
                        </div>
                        <Badge variant="secondary" className="bg-green-500/20 text-green-500">
                          +${userContract.totalProfit}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">المبلغ المستثمر:</span>
                          <span>${userContract.amount}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">الربح اليومي:</span>
                          <span className="text-green-500">${userContract.dailyProfit}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">المتبقي:</span>
                          <span>{getDaysRemaining(userContract.endDate)} يوم</span>
                        </div>
                        <div className="w-full">
                          <Progress 
                            value={calculateProgress(userContract.startDate, userContract.endDate)}
                            className="h-2"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground mb-4">لا توجد عقود نشطة حالياً</p>
                  <Link href="/contracts">
                    <Button className="bg-primary hover:bg-primary/90">
                      تصفح العقود المتاحة
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Transaction History */}
          <TransactionHistory />
        </div>
      </div>
    </Layout>
  );
}
