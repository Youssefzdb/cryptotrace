import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { MessageCircle, X, Headphones } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const TELEGRAM_SUPPORT_URL = "https://t.me/Chafcha_azizos";

export default function FloatingTelegramSupport() {
  const [isVisible, setIsVisible] = useState(true);
  const [isExpanded, setIsExpanded] = useState(false);
  const [lastScrollY, setLastScrollY] = useState(0);

  // Handle scroll behavior - hide when scrolling down
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY > lastScrollY && currentScrollY > 200) {
        // Scrolling down - hide support
        setIsVisible(false);
        setIsExpanded(false);
      } else if (currentScrollY < lastScrollY) {
        // Scrolling up - show support
        setIsVisible(true);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  // Auto-expand on first visit
  useEffect(() => {
    const hasSeenSupport = localStorage.getItem('telegram_support_seen');
    if (!hasSeenSupport) {
      setTimeout(() => {
        setIsExpanded(true);
        localStorage.setItem('telegram_support_seen', 'true');
      }, 3000);
    }
  }, []);

  const handleOpenTelegram = () => {
    window.open(TELEGRAM_SUPPORT_URL, '_blank', 'noopener,noreferrer');
    
    // Track interaction
    const interactions = parseInt(localStorage.getItem('support_interactions') || '0') + 1;
    localStorage.setItem('support_interactions', interactions.toString());
  };

  const handleToggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const handleClose = () => {
    setIsVisible(false);
    // Re-show after 30 seconds
    setTimeout(() => setIsVisible(true), 30000);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 100 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 100 }}
          transition={{ 
            type: "spring",
            stiffness: 260,
            damping: 20
          }}
          className="fixed bottom-6 left-6 z-50"
          style={{ direction: 'ltr' }}
        >
          {/* Expanded Support Card */}
          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, x: -20 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.9, x: -20 }}
                transition={{ duration: 0.2 }}
                className="mb-4 bg-card border border-border rounded-2xl shadow-2xl max-w-sm"
              >
                <div className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                        <Headphones className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-sm">الدعم الفني</h4>
                        <p className="text-xs text-muted-foreground">متاح 24/7</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleClose}
                      className="h-6 w-6 p-0 hover:bg-muted"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                    هل تحتاج مساعدة؟ فريق الدعم الفني جاهز لمساعدتك في أي وقت عبر Telegram
                  </p>
                  
                  <div className="flex gap-2">
                    <Button 
                      onClick={handleOpenTelegram}
                      className="flex-1 bg-blue-500 hover:bg-blue-600 text-white text-sm h-9"
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      فتح Telegram
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={handleToggleExpanded}
                      className="h-9 px-3"
                    >
                      إخفاء
                    </Button>
                  </div>
                  
                  {/* Online Status Indicator */}
                  <div className="flex items-center justify-center mt-3 pt-3 border-t border-border">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-xs text-muted-foreground">الدعم متاح الآن</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Floating Button */}
          <motion.div
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 20px 40px rgba(59, 130, 246, 0.3)"
            }}
            whileTap={{ scale: 0.95 }}
            className="relative"
          >
            <Button
              onClick={isExpanded ? handleOpenTelegram : handleToggleExpanded}
              className="w-14 h-14 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-300 border-0"
            >
              <div className="relative">
                <MessageCircle className="w-6 h-6 text-white" />
                
                {/* Notification Dot */}
                {!isExpanded && (
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white"
                  />
                )}
              </div>
            </Button>

            {/* Ripple Effect */}
            <div className="absolute inset-0 rounded-full">
              <motion.div
                animate={{ 
                  scale: [1, 1.5, 1],
                  opacity: [0.3, 0, 0.3]
                }}
                transition={{ 
                  repeat: Infinity, 
                  duration: 3,
                  ease: "easeInOut"
                }}
                className="w-full h-full bg-blue-500 rounded-full"
              />
            </div>
          </motion.div>

          {/* Tooltip for first-time users */}
          {!isExpanded && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1 }}
              className="absolute right-16 top-1/2 transform -translate-y-1/2 bg-gray-900 text-white text-xs px-3 py-2 rounded-lg whitespace-nowrap shadow-lg"
            >
              الدعم الفني
              <div className="absolute left-0 top-1/2 transform -translate-y-1/2 translate-x-1 w-0 h-0 border-t-4 border-b-4 border-r-4 border-transparent border-r-gray-900"></div>
            </motion.div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}