import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertContractSchema, insertUserContractSchema, insertTransactionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Generate referral code if not exists
      if (!user.referralCode) {
        const code = await storage.generateReferralCode(userId);
        user.referralCode = code;
      }

      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Contract routes
  app.get("/api/contracts", async (req, res) => {
    try {
      const contracts = await storage.getContracts();
      res.json(contracts);
    } catch (error) {
      console.error("Error fetching contracts:", error);
      res.status(500).json({ message: "Failed to fetch contracts" });
    }
  });

  app.get("/api/contracts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const contract = await storage.getContract(id);
      
      if (!contract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      res.json(contract);
    } catch (error) {
      console.error("Error fetching contract:", error);
      res.status(500).json({ message: "Failed to fetch contract" });
    }
  });

  // Contract purchase route
  app.post("/api/purchase", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { contractId, amount } = req.body;

      // Validate input types
      const contractIdNum = parseInt(contractId.toString());
      const amountStr = amount.toString();

      console.log("Purchase request:", { contractId: contractIdNum, amount: amountStr, userId });

      if (isNaN(contractIdNum)) {
        return res.status(400).json({ message: "Invalid contract ID" });
      }

      // Get user details to check balance
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check user balance
      const userBalance = parseFloat(user.balance || "0");
      const investmentAmount = parseFloat(amountStr);

      if (userBalance < investmentAmount) {
        return res.status(400).json({ 
          message: "رصيدك غير كافي للاستثمار. يرجى إيداع المزيد من الأموال أولاً",
          userBalance: userBalance.toFixed(2),
          requiredAmount: investmentAmount.toFixed(2)
        });
      }

      // Get contract details
      const contract = await storage.getContract(contractIdNum);
      if (!contract) {
        return res.status(404).json({ message: "Contract not found" });
      }

      // Check if contract is active and has available slots
      if (!contract.isActive || (contract.soldSlots || 0) >= contract.totalSlots) {
        return res.status(400).json({ message: "Contract not available" });
      }

      // Check minimum amount
      if (investmentAmount < parseFloat(contract.minAmount)) {
        return res.status(400).json({ message: "Amount below minimum required" });
      }

      // Check maximum amount
      if (contract.maxAmount && investmentAmount > parseFloat(contract.maxAmount)) {
        return res.status(400).json({ message: "Amount exceeds maximum allowed" });
      }

      // Calculate daily profit
      const dailyProfit = (investmentAmount * parseFloat(contract.dailyReturn)) / 100;
      
      // Calculate end date
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + contract.duration);

      // Deduct amount from user balance first
      await storage.updateUserBalance(userId, (-investmentAmount).toFixed(2));

      // Create user contract
      const userContract = await storage.purchaseContract({
        userId,
        contractId: contractIdNum,
        amount: amountStr,
        dailyProfit: dailyProfit.toFixed(2),
        endDate,
      });

      // Create transaction record
      await storage.createTransaction({
        userId,
        type: "contract_purchase",
        amount: `-${amountStr}`,
        description: `Purchase of ${contract.name} contract`,
        contractId: contractIdNum,
        status: "completed",
      });

      res.json({ 
        message: "Contract purchased successfully", 
        userContract,
        newBalance: (userBalance - investmentAmount).toFixed(2)
      });
    } catch (error) {
      console.error("Error purchasing contract:", error);
      res.status(500).json({ message: "Failed to purchase contract" });
    }
  });

  // User dashboard routes
  app.get("/api/dashboard/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  app.get("/api/dashboard/contracts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const contracts = await storage.getActiveUserContracts(userId);
      res.json(contracts);
    } catch (error) {
      console.error("Error fetching user contracts:", error);
      res.status(500).json({ message: "Failed to fetch user contracts" });
    }
  });

  app.get("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactions = await storage.getTransactions(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Referral routes
  app.get("/api/referrals", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const referrals = await storage.getReferrals(userId);
      res.json(referrals);
    } catch (error) {
      console.error("Error fetching referrals:", error);
      res.status(500).json({ message: "Failed to fetch referrals" });
    }
  });

  app.get("/api/referrals/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getReferralStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching referral stats:", error);
      res.status(500).json({ message: "Failed to fetch referral stats" });
    }
  });

  // Admin routes
  app.post("/api/admin/contracts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const contractData = insertContractSchema.parse(req.body);
      const contract = await storage.createContract(contractData);
      res.json(contract);
    } catch (error) {
      console.error("Error creating contract:", error);
      res.status(500).json({ message: "Failed to create contract" });
    }
  });

  app.put("/api/admin/contracts/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const id = parseInt(req.params.id);
      const contractData = insertContractSchema.partial().parse(req.body);
      const contract = await storage.updateContract(id, contractData);
      res.json(contract);
    } catch (error) {
      console.error("Error updating contract:", error);
      res.status(500).json({ message: "Failed to update contract" });
    }
  });

  app.delete("/api/admin/contracts/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const id = parseInt(req.params.id);
      await storage.deleteContract(id);
      res.json({ message: "Contract deleted successfully" });
    } catch (error) {
      console.error("Error deleting contract:", error);
      res.status(500).json({ message: "Failed to delete contract" });
    }
  });

  app.get("/api/admin/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
