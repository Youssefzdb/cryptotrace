import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  CheckCircle, 
  TrendingUp, 
  Users, 
  Shield,
  Bitcoin,
  Zap,
  DollarSign,
  Clock
} from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <nav className="border-b border-border px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="flex items-center space-x-2 space-x-reverse">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">CloudMine</span>
            </div>
          </div>
          <Button onClick={handleLogin} className="bg-primary hover:bg-primary/90">
            تسجيل الدخول
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="gradient-bg py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight text-right">
                ابدأ التعدين السحابي
                <span className="text-primary"> بسهولة وأمان</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed text-right">
                استثمر في عقود التعدين السحابي المتقدمة واحصل على عوائد يومية مضمونة من تعدين العملات الرقمية
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={handleLogin}
                  className="bg-primary hover:bg-primary/90 px-8 py-4 text-lg h-auto"
                >
                  ابدأ التعدين الآن
                </Button>
                <Button 
                  variant="outline" 
                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-4 text-lg h-auto"
                >
                  تعرف على المزيد
                </Button>
              </div>
            </div>
            
            {/* Stats Preview */}
            <Card className="mining-card">
              <CardHeader>
                <CardTitle className="text-xl text-right">إحصائيات المنصة المباشرة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400 profit-animation">$2.4M</div>
                    <div className="text-sm text-muted-foreground">إجمالي الأرباح</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-400">15,420</div>
                    <div className="text-sm text-muted-foreground">المستخدمين النشطين</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">2,847</div>
                    <div className="text-sm text-muted-foreground">العقود النشطة</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-400">99.9%</div>
                    <div className="text-sm text-muted-foreground">وقت التشغيل</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">لماذا CloudMine؟</h2>
            <p className="text-xl text-muted-foreground">المنصة الأكثر أماناً وربحية في الشرق الأوسط</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="mining-card text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">أمان عالي</h3>
                <p className="text-sm text-muted-foreground">حماية متقدمة لاستثماراتك مع تشفير من الدرجة العسكرية</p>
              </CardContent>
            </Card>

            <Card className="mining-card text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-6 h-6 text-green-500" />
                </div>
                <h3 className="font-semibold mb-2">عوائد يومية</h3>
                <p className="text-sm text-muted-foreground">احصل على أرباح يومية مضمونة من عقود التعدين</p>
              </CardContent>
            </Card>

            <Card className="mining-card text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="font-semibold mb-2">تقنية متقدمة</h3>
                <p className="text-sm text-muted-foreground">أحدث تقنيات التعدين السحابي والذكاء الاصطناعي</p>
              </CardContent>
            </Card>

            <Card className="mining-card text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-purple-500" />
                </div>
                <h3 className="font-semibold mb-2">دعم 24/7</h3>
                <p className="text-sm text-muted-foreground">فريق دعم متخصص متاح على مدار الساعة</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-16 px-4 bg-muted/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">كيف يعمل التعدين السحابي؟</h2>
            <p className="text-xl text-muted-foreground">خطوات بسيطة لبدء الاستثمار</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary-foreground">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">سجل واختر العقد</h3>
              <p className="text-muted-foreground">أنشئ حسابك واختر عقد التعدين المناسب لميزانيتك</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary-foreground">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">ابدأ التعدين</h3>
              <p className="text-muted-foreground">يبدأ التعدين تلقائياً بمجرد تأكيد الدفع</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary-foreground">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">احصل على الأرباح</h3>
              <p className="text-muted-foreground">تستلم الأرباح يومياً في محفظتك</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="gradient-bg py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            ابدأ رحلتك في التعدين السحابي اليوم
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            انضم لآلاف المستثمرين الذين يحققون أرباحاً يومية مع CloudMine
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-primary hover:bg-primary/90 px-8 py-4 text-lg h-auto"
          >
            ابدأ الآن - مجاناً
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 space-x-reverse mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold">CloudMine</span>
              </div>
              <p className="text-muted-foreground mb-4">منصة التعدين السحابي الرائدة في الشرق الأوسط</p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">الخدمات</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>تعدين البيتكوين</li>
                <li>تعدين الإيثريوم</li>
                <li>تعدين اللايتكوين</li>
                <li>العقود المخصصة</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">الدعم</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>مركز المساعدة</li>
                <li>اتصل بنا</li>
                <li>الأسئلة الشائعة</li>
                <li>دليل المستخدم</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">الشركة</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>من نحن</li>
                <li>الشروط والأحكام</li>
                <li>سياسة الخصوصية</li>
                <li>الأمان</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 CloudMine. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
