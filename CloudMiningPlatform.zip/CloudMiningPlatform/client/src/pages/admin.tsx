import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Contract, InsertContract } from "@shared/schema";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContractSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Users, DollarSign, TrendingUp, Activity, Plus, Edit, Trash2 } from "lucide-react";
import { z } from "zod";

type AdminStats = {
  totalUsers: number;
  totalContracts: number;
  totalRevenue: string;
  activeUsers: number;
};

const contractFormSchema = insertContractSchema.extend({
  minAmount: z.string().min(1, "الحد الأدنى مطلوب"),
  maxAmount: z.string().optional(),
  dailyReturn: z.string().min(1, "العائد اليومي مطلوب"),
  totalReturn: z.string().min(1, "إجمالي العائد مطلوب"),
  duration: z.string().min(1, "المدة مطلوبة"),
  totalSlots: z.string().min(1, "إجمالي الأماكن مطلوب"),
});

type ContractFormData = z.infer<typeof contractFormSchema>;

export default function Admin() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);
  const [editingContract, setEditingContract] = useState<Contract | null>(null);

  const { data: adminStats } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
    enabled: user?.isAdmin,
  });

  const { data: contracts, refetch: refetchContracts } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
    enabled: user?.isAdmin,
  });

  const form = useForm<ContractFormData>({
    resolver: zodResolver(contractFormSchema),
    defaultValues: {
      name: "",
      description: "",
      cryptocurrency: "",
      minAmount: "",
      maxAmount: "",
      dailyReturn: "",
      totalReturn: "",
      duration: "",
      totalSlots: "",
      isActive: true,
    },
  });

  const createContractMutation = useMutation({
    mutationFn: async (data: ContractFormData) => {
      const contractData = {
        ...data,
        minAmount: data.minAmount,
        maxAmount: data.maxAmount || null,
        dailyReturn: data.dailyReturn,
        totalReturn: data.totalReturn,
        duration: parseInt(data.duration),
        totalSlots: parseInt(data.totalSlots),
      };
      
      return await apiRequest("POST", "/api/admin/contracts", contractData);
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء العقد بنجاح",
        description: "تم إضافة العقد الجديد للمنصة",
      });
      form.reset();
      setIsCreating(false);
      refetchContracts();
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
    },
    onError: (error: any) => {
      toast({
        title: "فشل في إنشاء العقد",
        description: error.message || "حدث خطأ أثناء إنشاء العقد",
        variant: "destructive",
      });
    },
  });

  const updateContractMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<ContractFormData> }) => {
      const contractData = {
        ...data,
        ...(data.minAmount && { minAmount: data.minAmount }),
        ...(data.maxAmount && { maxAmount: data.maxAmount }),
        ...(data.dailyReturn && { dailyReturn: data.dailyReturn }),
        ...(data.totalReturn && { totalReturn: data.totalReturn }),
        ...(data.duration && { duration: parseInt(data.duration) }),
        ...(data.totalSlots && { totalSlots: parseInt(data.totalSlots) }),
      };
      
      return await apiRequest("PUT", `/api/admin/contracts/${id}`, contractData);
    },
    onSuccess: () => {
      toast({
        title: "تم تحديث العقد بنجاح",
        description: "تم حفظ التغييرات",
      });
      setEditingContract(null);
      form.reset();
      refetchContracts();
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
    },
    onError: (error: any) => {
      toast({
        title: "فشل في تحديث العقد",
        description: error.message || "حدث خطأ أثناء تحديث العقد",
        variant: "destructive",
      });
    },
  });

  const deleteContractMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/admin/contracts/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "تم حذف العقد بنجاح",
        description: "تم إزالة العقد من المنصة",
      });
      refetchContracts();
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
    },
    onError: (error: any) => {
      toast({
        title: "فشل في حذف العقد",
        description: error.message || "حدث خطأ أثناء حذف العقد",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: ContractFormData) => {
    if (editingContract) {
      updateContractMutation.mutate({ id: editingContract.id, data });
    } else {
      createContractMutation.mutate(data);
    }
  };

  const handleEdit = (contract: Contract) => {
    setEditingContract(contract);
    setIsCreating(true);
    form.reset({
      name: contract.name,
      description: contract.description || "",
      cryptocurrency: contract.cryptocurrency,
      minAmount: contract.minAmount,
      maxAmount: contract.maxAmount || "",
      dailyReturn: contract.dailyReturn,
      totalReturn: contract.totalReturn,
      duration: contract.duration.toString(),
      totalSlots: contract.totalSlots.toString(),
      isActive: contract.isActive,
    });
  };

  const handleDelete = (contract: Contract) => {
    if (confirm(`هل أنت متأكد من حذف العقد "${contract.name}"؟`)) {
      deleteContractMutation.mutate(contract.id);
    }
  };

  const handleCancelEdit = () => {
    setIsCreating(false);
    setEditingContract(null);
    form.reset();
  };

  // Check if user is admin
  if (!user?.isAdmin) {
    return (
      <Layout>
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <Card>
            <CardContent className="pt-6">
              <h1 className="text-2xl font-bold text-destructive mb-4">غير مصرح</h1>
              <p className="text-muted-foreground">ليس لديك صلاحية للوصول لهذه الصفحة</p>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">لوحة تحكم المدير</h1>
          <Badge variant="secondary" className="bg-primary/20 text-primary">
            المدير
          </Badge>
        </div>

        {/* Admin Stats */}
        {adminStats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="mining-card">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">إجمالي المستخدمين</p>
                    <p className="text-2xl font-bold">{adminStats.totalUsers}</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mining-card">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">إجمالي العقود</p>
                    <p className="text-2xl font-bold">{adminStats.totalContracts}</p>
                  </div>
                  <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-green-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mining-card">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">إجمالي الإيرادات</p>
                    <p className="text-2xl font-bold">${adminStats.totalRevenue}</p>
                  </div>
                  <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-yellow-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mining-card">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">المستخدمين النشطين</p>
                    <p className="text-2xl font-bold">{adminStats.activeUsers}</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                    <Activity className="w-6 h-6 text-purple-500" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Contract Management */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contract Form */}
          <Card className="mining-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{editingContract ? "تعديل العقد" : "إضافة عقد جديد"}</span>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsCreating(!isCreating)}
                >
                  {isCreating ? "إلغاء" : <Plus className="w-4 h-4" />}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isCreating ? (
                <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">اسم العقد</Label>
                      <Input 
                        id="name"
                        {...form.register("name")}
                        placeholder="Bitcoin Starter"
                      />
                      {form.formState.errors.name && (
                        <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="cryptocurrency">العملة الرقمية</Label>
                      <Select onValueChange={(value) => form.setValue("cryptocurrency", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر العملة" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                          <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                          <SelectItem value="LTC">Litecoin (LTC)</SelectItem>
                        </SelectContent>
                      </Select>
                      {form.formState.errors.cryptocurrency && (
                        <p className="text-sm text-destructive">{form.formState.errors.cryptocurrency.message}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="description">الوصف</Label>
                    <Textarea 
                      id="description"
                      {...form.register("description")}
                      placeholder="وصف العقد..."
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="minAmount">الحد الأدنى ($)</Label>
                      <Input 
                        id="minAmount"
                        {...form.register("minAmount")}
                        placeholder="100.00"
                      />
                      {form.formState.errors.minAmount && (
                        <p className="text-sm text-destructive">{form.formState.errors.minAmount.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="maxAmount">الحد الأقصى ($)</Label>
                      <Input 
                        id="maxAmount"
                        {...form.register("maxAmount")}
                        placeholder="10000.00"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="dailyReturn">العائد اليومي (%)</Label>
                      <Input 
                        id="dailyReturn"
                        {...form.register("dailyReturn")}
                        placeholder="2.50"
                      />
                      {form.formState.errors.dailyReturn && (
                        <p className="text-sm text-destructive">{form.formState.errors.dailyReturn.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="totalReturn">إجمالي العائد (%)</Label>
                      <Input 
                        id="totalReturn"
                        {...form.register("totalReturn")}
                        placeholder="130.00"
                      />
                      {form.formState.errors.totalReturn && (
                        <p className="text-sm text-destructive">{form.formState.errors.totalReturn.message}</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="duration">المدة (أيام)</Label>
                      <Input 
                        id="duration"
                        {...form.register("duration")}
                        placeholder="365"
                      />
                      {form.formState.errors.duration && (
                        <p className="text-sm text-destructive">{form.formState.errors.duration.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="totalSlots">إجمالي الأماكن</Label>
                      <Input 
                        id="totalSlots"
                        {...form.register("totalSlots")}
                        placeholder="1000"
                      />
                      {form.formState.errors.totalSlots && (
                        <p className="text-sm text-destructive">{form.formState.errors.totalSlots.message}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button 
                      type="submit" 
                      className="flex-1"
                      disabled={createContractMutation.isPending || updateContractMutation.isPending}
                    >
                      {editingContract ? "تحديث العقد" : "إنشاء العقد"}
                    </Button>
                    {editingContract && (
                      <Button type="button" variant="outline" onClick={handleCancelEdit}>
                        إلغاء
                      </Button>
                    )}
                  </div>
                </form>
              ) : (
                <div className="text-center py-8">
                  <Plus className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">انقر على "إضافة عقد جديد" لإنشاء عقد تعدين جديد</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Contracts List */}
          <Card className="mining-card">
            <CardHeader>
              <CardTitle>العقود الحالية</CardTitle>
            </CardHeader>
            <CardContent>
              {contracts && contracts.length > 0 ? (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {contracts.map((contract) => (
                    <div key={contract.id} className="border border-border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{contract.name}</h4>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(contract)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDelete(contract)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                        <div>العملة: {contract.cryptocurrency}</div>
                        <div>العائد اليومي: {contract.dailyReturn}%</div>
                        <div>الحد الأدنى: ${contract.minAmount}</div>
                        <div>المدة: {contract.duration} يوم</div>
                        <div>المبيع: {contract.soldSlots}/{contract.totalSlots}</div>
                        <div>
                          <Badge variant={contract.isActive ? "default" : "secondary"}>
                            {contract.isActive ? "نشط" : "غير نشط"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">لا توجد عقود متاحة حالياً</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
