import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { 
  Copy, 
  QrCode, 
  Clock, 
  Shield, 
  CheckCircle, 
  AlertTriangle,
  TrendingUp,
  Wallet,
  Eye,
  EyeOff
} from "lucide-react";

const DEPOSIT_ADDRESS = "TR2AQWkYfU29n2dh8LMPQL5WvZVSrPkzHa";
const MIN_DEPOSIT = 50;

export default function Deposit() {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [showAddress, setShowAddress] = useState(false);
  const [captchaVerified, setCaptchaVerified] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState("");

  // Generate QR Code URL
  useEffect(() => {
    if (showAddress && captchaVerified) {
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${DEPOSIT_ADDRESS}&bgcolor=1F1F3A&color=E43F5A&format=png&ecc=M`;
      setQrCodeUrl(qrUrl);
    }
  }, [showAddress, captchaVerified]);

  // Validate TRON address
  const validateTronAddress = (address: string): boolean => {
    const tronRegex = /^T[a-zA-Z0-9]{33}$/;
    return tronRegex.test(address);
  };

  // Simple CAPTCHA verification
  const handleCaptchaVerification = () => {
    const answer = prompt("للأمان، كم هو ناتج: 5 + 3 = ?");
    if (answer === "8") {
      setCaptchaVerified(true);
      setShowAddress(true);
      toast({
        title: "تم التحقق بنجاح",
        description: "يمكنك الآن رؤية عنوان الإيداع",
      });
    } else {
      toast({
        title: "خطأ في التحقق",
        description: "الإجابة غير صحيحة، حاول مرة أخرى",
        variant: "destructive",
      });
    }
  };

  // Copy address with enhanced UX
  const handleCopyAddress = async () => {
    if (!validateTronAddress(DEPOSIT_ADDRESS)) {
      toast({
        title: "خطأ في العنوان",
        description: "عنوان TRON غير صالح",
        variant: "destructive",
      });
      return;
    }

    try {
      await navigator.clipboard.writeText(DEPOSIT_ADDRESS);
      setCopied(true);
      
      // Store encrypted address in localStorage
      const encrypted = btoa(DEPOSIT_ADDRESS);
      localStorage.setItem('last_deposit_addr', encrypted);
      
      toast({
        title: "تم نسخ العنوان بنجاح! 🎉",
        description: "تم نسخ عنوان TRON إلى الحافظة",
      });

      // Reset copy state after 3 seconds
      setTimeout(() => setCopied(false), 3000);
    } catch (error) {
      // Fallback for older browsers
      const textArea = document.createElement("textarea");
      textArea.value = DEPOSIT_ADDRESS;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      
      setCopied(true);
      toast({
        title: "تم نسخ العنوان",
        description: "تم نسخ عنوان TRON إلى الحافظة",
      });
      setTimeout(() => setCopied(false), 3000);
    }
  };

  return (
    <Layout>
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
              <Wallet className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">إيداع TRX</h1>
          <p className="text-xl text-muted-foreground">
            قم بإيداع عملة TRON (TRX) لبدء الاستثمار في عقود التعدين السحابي
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Deposit Address Card */}
          <Card className="mining-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <QrCode className="w-6 h-6 text-primary" />
                <span>عنوان الإيداع</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Security Verification */}
                {!captchaVerified && (
                  <Alert className="border-yellow-500/20 bg-yellow-500/10">
                    <Shield className="w-4 h-4" />
                    <AlertDescription className="text-right">
                      للحماية والأمان، يجب التحقق أولاً قبل عرض العنوان
                      <Button 
                        onClick={handleCaptchaVerification}
                        className="mt-2 bg-primary hover:bg-primary/90 w-full"
                      >
                        <Shield className="w-4 h-4 ml-2" />
                        التحقق الأمني
                      </Button>
                    </AlertDescription>
                  </Alert>
                )}

                {/* Address Display */}
                {showAddress && captchaVerified && (
                  <>
                    <div className="text-center space-y-4">
                      {/* QR Code */}
                      <div className="flex justify-center">
                        <div className="p-4 bg-white rounded-2xl shadow-lg">
                          <img 
                            src={qrCodeUrl} 
                            alt="TRON Address QR Code"
                            className="w-48 h-48 mx-auto"
                            loading="lazy"
                          />
                        </div>
                      </div>

                      {/* Address Text */}
                      <div className="space-y-3">
                        <div className="bg-secondary rounded-lg p-4 border-2 border-primary/20">
                          <div className="flex items-center justify-between">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setShowAddress(!showAddress)}
                              className="text-muted-foreground"
                            >
                              {showAddress ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </Button>
                            <code className="text-sm font-mono break-all text-center flex-1 px-2">
                              {DEPOSIT_ADDRESS}
                            </code>
                            <div className="w-6"></div>
                          </div>
                        </div>

                        <Button 
                          onClick={handleCopyAddress}
                          className={`w-full h-12 font-semibold transition-all duration-300 ${
                            copied 
                              ? "bg-green-500 hover:bg-green-600 text-white" 
                              : "bg-primary hover:bg-primary/90"
                          }`}
                        >
                          {copied ? (
                            <>
                              <CheckCircle className="w-5 h-5 ml-2" />
                              تم النسخ بنجاح!
                            </>
                          ) : (
                            <>
                              <Copy className="w-5 h-5 ml-2" />
                              نسخ العنوان
                            </>
                          )}
                        </Button>
                      </div>
                    </div>

                    {/* Validation Badge */}
                    <div className="flex justify-center">
                      <Badge className="bg-green-500/20 text-green-500 border-green-500/20">
                        <Shield className="w-3 h-3 ml-1" />
                        عنوان TRON محقق
                      </Badge>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Instructions Card */}
          <Card className="mining-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <AlertTriangle className="w-6 h-6 text-yellow-500" />
                <span>تعليمات الإيداع</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Key Information */}
                <div className="grid grid-cols-1 gap-4">
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">الحد الأدنى للإيداع:</span>
                    <Badge className="bg-primary/20 text-primary">
                      {MIN_DEPOSIT} TRX
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">وقت التأكيد:</span>
                    <Badge className="bg-blue-500/20 text-blue-500">
                      <Clock className="w-3 h-3 ml-1" />
                      1-3 دقائق
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">الشبكة:</span>
                    <Badge className="bg-green-500/20 text-green-500">
                      TRON (TRX)
                    </Badge>
                  </div>
                </div>

                {/* Step-by-step Instructions */}
                <div className="space-y-4">
                  <h4 className="font-semibold text-right">خطوات الإيداع:</h4>
                  
                  <div className="space-y-3">
                    {[
                      {
                        step: "1",
                        title: "انسخ العنوان",
                        description: "انسخ عنوان TRON أعلاه أو امسح QR Code",
                        color: "bg-blue-500"
                      },
                      {
                        step: "2", 
                        title: "افتح محفظتك",
                        description: "افتح TrustWallet أو TronLink أو أي محفظة TRON",
                        color: "bg-purple-500"
                      },
                      {
                        step: "3",
                        title: "أرسل TRX",
                        description: `أرسل ما لا يقل عن ${MIN_DEPOSIT} TRX إلى العنوان`,
                        color: "bg-green-500"
                      },
                      {
                        step: "4",
                        title: "انتظر التأكيد",
                        description: "سيظهر الرصيد في حسابك خلال 1-3 دقائق",
                        color: "bg-yellow-500"
                      }
                    ].map((item, index) => (
                      <div key={index} className="flex items-start space-x-3 space-x-reverse">
                        <div className={`w-8 h-8 ${item.color} rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0`}>
                          {item.step}
                        </div>
                        <div className="flex-1">
                          <h5 className="font-medium mb-1">{item.title}</h5>
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Important Notes */}
                <Alert className="border-red-500/20 bg-red-500/10">
                  <AlertTriangle className="w-4 h-4" />
                  <AlertDescription className="text-right">
                    <strong>تنبيهات مهمة:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                      <li>تأكد من استخدام شبكة TRON فقط</li>
                      <li>لا ترسل عملات أخرى لهذا العنوان</li>
                      <li>الحد الأدنى {MIN_DEPOSIT} TRX لتجنب فقدان الأموال</li>
                      <li>احتفظ بـ hash المعاملة للمرجع</li>
                    </ul>
                  </AlertDescription>
                </Alert>

                {/* Supported Wallets */}
                <div className="space-y-3">
                  <h4 className="font-semibold text-right">المحافظ المدعومة:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      "TrustWallet",
                      "TronLink",
                      "Klever",
                      "Atomic Wallet"
                    ].map((wallet) => (
                      <Badge key={wallet} variant="outline" className="justify-center p-2">
                        {wallet}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Deposit Benefits */}
        <Card className="mining-card mt-8">
          <CardHeader>
            <CardTitle className="text-center">
              <TrendingUp className="w-6 h-6 inline ml-2" />
              مزايا الإيداع بـ TRX
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  title: "رسوم منخفضة",
                  description: "رسوم تحويل منخفضة جداً مقارنة بالعملات الأخرى",
                  icon: "💰"
                },
                {
                  title: "سرعة عالية",
                  description: "تأكيدات سريعة خلال ثوانٍ معدودة",
                  icon: "⚡"
                },
                {
                  title: "أمان مضمون",
                  description: "شبكة TRON آمنة ومستقرة مع blockchain موثوق",
                  icon: "🔒"
                }
              ].map((benefit, index) => (
                <div key={index} className="text-center p-4 bg-secondary rounded-lg">
                  <div className="text-3xl mb-3">{benefit.icon}</div>
                  <h4 className="font-semibold mb-2">{benefit.title}</h4>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}