import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Contract } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { DollarSign, Clock, TrendingUp } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface ContractCardProps {
  contract: Contract;
}

export default function ContractCard({ contract }: ContractCardProps) {
  const { toast } = useToast();
  const [purchaseAmount, setPurchaseAmount] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const getCryptocurrencyIcon = (crypto: string) => {
    switch (crypto.toLowerCase()) {
      case 'btc':
      case 'bitcoin':
        return '₿';
      case 'eth':
      case 'ethereum':
        return 'Ξ';
      case 'ltc':
      case 'litecoin':
        return 'Ł';
      default:
        return '₿';
    }
  };

  const getCryptocurrencyColor = (crypto: string) => {
    switch (crypto.toLowerCase()) {
      case 'btc':
      case 'bitcoin':
        return 'bg-yellow-500';
      case 'eth':
      case 'ethereum':
        return 'bg-blue-500';
      case 'ltc':
      case 'litecoin':
        return 'bg-gray-400';
      default:
        return 'bg-yellow-500';
    }
  };

  const purchaseMutation = useMutation({
    mutationFn: async ({ contractId, amount }: { contractId: number; amount: string }) => {
      return await apiRequest("POST", "/api/purchase", { contractId, amount });
    },
    onSuccess: () => {
      toast({
        title: "تم شراء العقد بنجاح",
        description: "سيبدأ التعدين خلال 24 ساعة وستحصل على الأرباح يومياً",
      });
      setIsDialogOpen(false);
      setPurchaseAmount("");
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
    },
    onError: (error: any) => {
      toast({
        title: "فشل في شراء العقد",
        description: error.message || "حدث خطأ أثناء شراء العقد",
        variant: "destructive",
      });
    },
  });

  const handlePurchase = () => {
    if (!purchaseAmount || parseFloat(purchaseAmount) < parseFloat(contract.minAmount)) {
      toast({
        title: "مبلغ غير صالح",
        description: `الحد الأدنى للاستثمار هو $${contract.minAmount}`,
        variant: "destructive",
      });
      return;
    }

    if (contract.maxAmount && parseFloat(purchaseAmount) > parseFloat(contract.maxAmount)) {
      toast({
        title: "مبلغ غير صالح",
        description: `الحد الأقصى للاستثمار هو $${contract.maxAmount}`,
        variant: "destructive",
      });
      return;
    }

    purchaseMutation.mutate({ contractId: contract.id, amount: purchaseAmount });
  };

  const soldPercentage = (contract.soldSlots / contract.totalSlots) * 100;
  const isAvailable = contract.isActive && contract.soldSlots < contract.totalSlots;

  return (
    <Card className="mining-card hover:shadow-2xl transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className={`w-10 h-10 ${getCryptocurrencyColor(contract.cryptocurrency)} rounded-full flex items-center justify-center`}>
              <span className="text-white font-bold">
                {getCryptocurrencyIcon(contract.cryptocurrency)}
              </span>
            </div>
            <div>
              <h3 className="font-semibold">{contract.name}</h3>
              <p className="text-sm text-muted-foreground">
                مدة العقد: {contract.duration} يوم
              </p>
            </div>
          </div>
          <Badge variant={isAvailable ? "default" : "secondary"} className={isAvailable ? "bg-green-500 text-white" : ""}>
            {isAvailable ? "نشط" : "مكتمل"}
          </Badge>
        </div>
        
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground text-sm">الحد الأدنى:</span>
            <span className="font-semibold">${contract.minAmount}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground text-sm">العائد اليومي:</span>
            <span className="font-semibold text-green-500">{contract.dailyReturn}%</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground text-sm">إجمالي العائد:</span>
            <span className="font-semibold text-yellow-500">{contract.totalReturn}%</span>
          </div>
          
          {/* Progress Bar */}
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">المبيع:</span>
              <span>{contract.soldSlots}/{contract.totalSlots}</span>
            </div>
            <Progress value={soldPercentage} className="h-2" />
          </div>

          {contract.description && (
            <p className="text-sm text-muted-foreground">{contract.description}</p>
          )}

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="w-full bg-primary hover:bg-primary/90" 
                disabled={!isAvailable}
              >
                {isAvailable ? "شراء العقد" : "غير متاح"}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle className="text-right">شراء العقد - {contract.name}</DialogTitle>
                <DialogDescription className="text-right">
                  أدخل المبلغ الذي تريد استثماره في هذا العقد
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="amount" className="text-right">
                    مبلغ الاستثمار ($)
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    min={contract.minAmount}
                    max={contract.maxAmount || undefined}
                    step="0.01"
                    placeholder={`الحد الأدنى: $${contract.minAmount}`}
                    value={purchaseAmount}
                    onChange={(e) => setPurchaseAmount(e.target.value)}
                    className="text-right"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>الحد الأدنى: ${contract.minAmount}</span>
                    {contract.maxAmount && <span>الحد الأقصى: ${contract.maxAmount}</span>}
                  </div>
                </div>

                {purchaseAmount && parseFloat(purchaseAmount) >= parseFloat(contract.minAmount) && (
                  <div className="bg-muted rounded-lg p-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">الربح اليومي المتوقع:</span>
                      <span className="font-semibold text-green-500">
                        ${((parseFloat(purchaseAmount) * parseFloat(contract.dailyReturn)) / 100).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">إجمالي الأرباح المتوقعة:</span>
                      <span className="font-semibold text-yellow-500">
                        ${((parseFloat(purchaseAmount) * parseFloat(contract.totalReturn)) / 100).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">مدة العقد:</span>
                      <span className="font-semibold">{contract.duration} يوم</span>
                    </div>
                  </div>
                )}
              </div>
              
              <DialogFooter className="gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                  className="flex-1"
                >
                  إلغاء
                </Button>
                <Button 
                  onClick={handlePurchase}
                  disabled={!purchaseAmount || parseFloat(purchaseAmount) < parseFloat(contract.minAmount) || purchaseMutation.isPending}
                  className="flex-1 bg-primary hover:bg-primary/90"
                >
                  {purchaseMutation.isPending ? "جاري المعالجة..." : "تأكيد الشراء"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
    </Card>
  );
}
